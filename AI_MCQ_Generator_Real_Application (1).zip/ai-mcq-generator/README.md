# AI-Based MCQ Generator from PDF Notes

Student mini-project by K. Sai Yashas (25011CSEAI0144), CSE-AIML, Sreenidhi University. Faculty guide: P. Ravinder.

## What it does
- Upload a PDF with selectable text.
- Create draft MCQs from sentences in the PDF.
- Take a quiz and receive an automatic score.
- Review answers and download questions as a TXT file.

## Run on your computer
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install dependencies:
   `pip install -r requirements.txt`
4. Run:
   `streamlit run app.py`
5. Open the local address printed by Streamlit.

## Publish as an online shareable website (free tier)
1. Create a GitHub repository and upload `app.py`, `requirements.txt`, and `README.md`.
2. Sign in to Streamlit Community Cloud with GitHub.
3. Select **Create app**, choose your repository, branch, and `app.py`.
4. Deploy and share the URL Streamlit provides.

## Honest limitation
This first free version uses a simple offline method: it hides a selected term in a sentence from the PDF and offers other words as distractors. It is a real working prototype with quiz scoring, but it is not a deep-understanding AI model and its questions may be awkward or incorrect. Check answers against the PDF. Scanned/image-only PDFs need OCR, which is not included.
