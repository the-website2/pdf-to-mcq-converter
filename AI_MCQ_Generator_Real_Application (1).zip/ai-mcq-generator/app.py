import re
import random
import streamlit as st
import fitz

st.set_page_config(page_title="AI MCQ Generator", page_icon="📝", layout="wide")
st.title("📝 AI-Based MCQ Generator from PDF Notes")
st.write("Upload study notes, generate practice questions, and take a quiz with automatic scoring.")
st.info("This is a student prototype. Always check generated answers against your original notes.")

with st.sidebar:
    st.header("How to use")
    st.write("1. Upload a text-based PDF.")
    st.write("2. Generate questions.")
    st.write("3. Take the quiz.")
    st.write("4. Submit to see your score.")

def extract_text(file):
    with fitz.open(stream=file.getvalue(), filetype="pdf") as pdf:
        return "\n".join(page.get_text("text") for page in pdf)

def sentences_from(text):
    text = re.sub(r"\s+", " ", text)
    return [s.strip(" •-\n") for s in re.split(r"(?<=[.!?])\s+", text)
            if 45 <= len(s.strip()) <= 280 and len(s.split()) >= 7]

def terms_from(sentence):
    stop = {"this","that","these","those","which","where","there","their","about","because",
            "while","after","before","between","through","using","used","from","into","with",
            "have","been","being","were","will","would","should","could","when","what","such",
            "than","then","also","most","more","less","some","many","each","every","other",
            "only","both","they","them","your","shall","must","does","done","make","made"}
    found = []
    for word in re.findall(r"\b[A-Za-z][A-Za-z0-9-]{3,}\b", sentence):
        if word.lower() not in stop and word.lower() not in [x.lower() for x in found]:
            found.append(word)
    return found

def make_questions(text, count):
    sentences = sentences_from(text)
    pool = []
    for s in sentences:
        pool.extend(terms_from(s))
    pool = list(dict.fromkeys(pool))
    questions = []
    used = set()
    random.seed(9)
    for sentence in sentences:
        if len(questions) >= count:
            break
        candidates = [t for t in terms_from(sentence) if 4 <= len(t) <= 22 and t.lower() not in used]
        if not candidates:
            continue
        answer = candidates[-1]
        used.add(answer.lower())
        question = re.sub(re.escape(answer), "________", sentence, count=1, flags=re.I)
        distractors = [t for t in pool if t.lower() != answer.lower() and t.lower() not in sentence.lower()]
        choices = []
        for d in distractors + ["Concept", "Process", "Method", "Structure", "System"]:
            if d.lower() != answer.lower() and d.lower() not in [x.lower() for x in choices]:
                choices.append(d)
            if len(choices) == 3:
                break
        options = choices + [answer]
        random.shuffle(options)
        questions.append({"question": question, "options": options,
                          "answer_index": options.index(answer), "answer": answer})
    return questions

uploaded = st.file_uploader("Upload PDF notes", type=["pdf"])
count = st.slider("Number of questions", 3, 20, 10)

if uploaded and st.button("Generate MCQs", type="primary"):
    with st.spinner("Reading PDF and creating practice questions..."):
        text = extract_text(uploaded)
        if len(text.strip()) < 100:
            st.error("No readable text found. Scanned PDFs are not supported in this version.")
        else:
            qs = make_questions(text, count)
            if qs:
                st.session_state["questions"] = qs
                st.session_state.pop("submitted", None)
            else:
                st.error("Could not create questions from this PDF. Try a PDF with full sentences.")

if "questions" in st.session_state:
    qs = st.session_state["questions"]
    st.subheader("Generated questions")
    st.caption("Free offline draft generator: it hides a term in a sentence from your PDF. Quality varies, so verify the answers.")
    export = []
    for i, q in enumerate(qs, 1):
        st.markdown(f"**Q{i}. {q['question']}**")
        for j, option in enumerate(q["options"]):
            st.write(f"{chr(65+j)}. {option}")
        st.caption(f"Suggested answer: {chr(65+q['answer_index'])}. {q['answer']}")
        export += [f"Q{i}. {q['question']}"] + [f"{chr(65+j)}. {o}" for j,o in enumerate(q["options"])] + [f"Answer: {q['answer']}", ""]
    st.download_button("Download questions as TXT", "\n".join(export), "generated_mcqs.txt", mime="text/plain")
    st.divider()
    st.subheader("Take the quiz")
    with st.form("quiz"):
        answers = {}
        for i, q in enumerate(qs):
            answers[i] = st.radio(
                f"Q{i+1}. {q['question']}",
                range(len(q["options"])),
                format_func=lambda n, opts=q["options"]: f"{chr(65+n)}. {opts[n]}",
                key=f"answer_{i}"
            )
        submit = st.form_submit_button("Submit quiz", type="primary")
    if submit:
        score = sum(answers[i] == q["answer_index"] for i, q in enumerate(qs))
        st.session_state["submitted"] = True
        st.session_state["score"] = score
        st.session_state["answers"] = answers
    if st.session_state.get("submitted"):
        score, total = st.session_state["score"], len(qs)
        st.success(f"Your score: {score}/{total} ({round(score/total*100)}%)")
        st.progress(score / total)
        with st.expander("Review answers"):
            for i, q in enumerate(qs):
                chosen = st.session_state["answers"][i]
                st.write(f"Q{i+1}: Your answer: {q['options'][chosen]} | Suggested answer: {q['answer']}")
st.caption("Student project by K. Sai Yashas · 25011CSEAI0144 · Faculty Guide: P. Ravinder")
